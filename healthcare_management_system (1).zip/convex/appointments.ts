import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createAppointment = mutation({
  args: {
    doctorId: v.id("userProfiles"),
    hospitalId: v.id("userProfiles"),
    appointmentDate: v.string(),
    appointmentTime: v.string(),
    symptoms: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const patientProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!patientProfile || patientProfile.role !== "patient") {
      throw new Error("Only patients can book appointments");
    }

    return await ctx.db.insert("appointments", {
      patientId: patientProfile._id,
      doctorId: args.doctorId,
      hospitalId: args.hospitalId,
      appointmentDate: args.appointmentDate,
      appointmentTime: args.appointmentTime,
      status: "scheduled",
      symptoms: args.symptoms,
    });
  },
});

export const getMyAppointments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile) return [];

    let appointments: any[] = [];

    if (userProfile.role === "patient") {
      appointments = await ctx.db
        .query("appointments")
        .withIndex("by_patient", (q) => q.eq("patientId", userProfile._id))
        .collect();
    } else if (userProfile.role === "doctor") {
      appointments = await ctx.db
        .query("appointments")
        .withIndex("by_doctor", (q) => q.eq("doctorId", userProfile._id))
        .collect();
    } else if (userProfile.role === "hospital") {
      appointments = await ctx.db
        .query("appointments")
        .withIndex("by_hospital", (q) => q.eq("hospitalId", userProfile._id))
        .collect();
    }

    // Get related user details
    const enrichedAppointments = await Promise.all(
      appointments.map(async (appointment) => {
        const patient = await ctx.db.get(appointment.patientId);
        const doctor = await ctx.db.get(appointment.doctorId);
        const hospital = await ctx.db.get(appointment.hospitalId);

        return {
          ...appointment,
          patient,
          doctor,
          hospital,
        };
      })
    );

    return enrichedAppointments;
  },
});

export const updateAppointmentStatus = mutation({
  args: {
    appointmentId: v.id("appointments"),
    status: v.union(
      v.literal("scheduled"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
    diagnosis: v.optional(v.string()),
    prescription: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || (userProfile.role !== "doctor" && userProfile.role !== "hospital")) {
      throw new Error("Only doctors and hospitals can update appointment status");
    }

    await ctx.db.patch(args.appointmentId, {
      status: args.status,
      diagnosis: args.diagnosis,
      prescription: args.prescription,
    });
  },
});
