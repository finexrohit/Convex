import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Extended user profiles with roles
  userProfiles: defineTable({
    userId: v.id("users"),
    role: v.union(
      v.literal("admin"),
      v.literal("hospital"),
      v.literal("doctor"),
      v.literal("medical_store"),
      v.literal("patient")
    ),
    name: v.string(),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    // Hospital-specific fields
    hospitalName: v.optional(v.string()),
    hospitalLicense: v.optional(v.string()),
    // Doctor-specific fields
    specialization: v.optional(v.string()),
    licenseNumber: v.optional(v.string()),
    hospitalId: v.optional(v.id("userProfiles")),
    // Medical store-specific fields
    storeName: v.optional(v.string()),
    storeAddress: v.optional(v.string()),
    pharmacyLicense: v.optional(v.string()),
    // Patient-specific fields
    dateOfBirth: v.optional(v.string()),
    bloodGroup: v.optional(v.string()),
    emergencyContact: v.optional(v.string()),
    isApproved: v.boolean(),
  })
    .index("by_user_id", ["userId"])
    .index("by_role", ["role"])
    .index("by_hospital", ["hospitalId"])
    .index("by_approval_status", ["isApproved"]),

  // Appointments
  appointments: defineTable({
    patientId: v.id("userProfiles"),
    doctorId: v.id("userProfiles"),
    hospitalId: v.id("userProfiles"),
    appointmentDate: v.string(),
    appointmentTime: v.string(),
    status: v.union(
      v.literal("scheduled"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
    symptoms: v.optional(v.string()),
    diagnosis: v.optional(v.string()),
    prescription: v.optional(v.string()),
  })
    .index("by_patient", ["patientId"])
    .index("by_doctor", ["doctorId"])
    .index("by_hospital", ["hospitalId"])
    .index("by_status", ["status"]),

  // Medicine inventory
  medicines: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    manufacturer: v.string(),
    category: v.string(),
    price: v.number(),
    storeId: v.id("userProfiles"),
    stockQuantity: v.number(),
    expiryDate: v.string(),
    requiresPrescription: v.boolean(),
  })
    .index("by_store", ["storeId"])
    .index("by_category", ["category"])
    .index("by_name", ["name"]),

  // Medicine orders
  medicineOrders: defineTable({
    patientId: v.id("userProfiles"),
    storeId: v.id("userProfiles"),
    medicines: v.array(v.object({
      medicineId: v.id("medicines"),
      quantity: v.number(),
      price: v.number(),
    })),
    totalAmount: v.number(),
    status: v.union(
      v.literal("pending"),
      v.literal("confirmed"),
      v.literal("delivered"),
      v.literal("cancelled")
    ),
    prescriptionRequired: v.boolean(),
    prescriptionImage: v.optional(v.id("_storage")),
    deliveryAddress: v.string(),
  })
    .index("by_patient", ["patientId"])
    .index("by_store", ["storeId"])
    .index("by_status", ["status"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
