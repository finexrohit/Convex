import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const addMedicine = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    manufacturer: v.string(),
    category: v.string(),
    price: v.number(),
    stockQuantity: v.number(),
    expiryDate: v.string(),
    requiresPrescription: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "medical_store") {
      throw new Error("Only medical stores can add medicines");
    }

    return await ctx.db.insert("medicines", {
      ...args,
      storeId: userProfile._id,
    });
  },
});

export const getMedicines = query({
  args: { storeId: v.optional(v.id("userProfiles")) },
  handler: async (ctx, args) => {
    if (args.storeId) {
      return await ctx.db
        .query("medicines")
        .withIndex("by_store", (q) => q.eq("storeId", args.storeId!))
        .collect();
    }

    return await ctx.db.query("medicines").collect();
  },
});

export const searchMedicines = query({
  args: { searchTerm: v.string() },
  handler: async (ctx, args) => {
    const allMedicines = await ctx.db.query("medicines").collect();
    
    return allMedicines.filter(medicine => 
      medicine.name.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      medicine.category.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      medicine.manufacturer.toLowerCase().includes(args.searchTerm.toLowerCase())
    );
  },
});

export const createMedicineOrder = mutation({
  args: {
    storeId: v.id("userProfiles"),
    medicines: v.array(v.object({
      medicineId: v.id("medicines"),
      quantity: v.number(),
      price: v.number(),
    })),
    totalAmount: v.number(),
    prescriptionRequired: v.boolean(),
    prescriptionImage: v.optional(v.id("_storage")),
    deliveryAddress: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const patientProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!patientProfile || patientProfile.role !== "patient") {
      throw new Error("Only patients can place medicine orders");
    }

    return await ctx.db.insert("medicineOrders", {
      patientId: patientProfile._id,
      ...args,
      status: "pending",
    });
  },
});

export const getMedicineOrders = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile) return [];

    let orders: any[] = [];

    if (userProfile.role === "patient") {
      orders = await ctx.db
        .query("medicineOrders")
        .withIndex("by_patient", (q) => q.eq("patientId", userProfile._id))
        .collect();
    } else if (userProfile.role === "medical_store") {
      orders = await ctx.db
        .query("medicineOrders")
        .withIndex("by_store", (q) => q.eq("storeId", userProfile._id))
        .collect();
    }

    return orders;
  },
});
