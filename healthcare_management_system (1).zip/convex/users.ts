import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getCurrentUserProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const user = await ctx.db.get(userId);
    if (!user) return null;

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    return { user, profile };
  },
});

export const createUserProfile = mutation({
  args: {
    role: v.union(
      v.literal("admin"),
      v.literal("hospital"),
      v.literal("doctor"),
      v.literal("medical_store"),
      v.literal("patient")
    ),
    name: v.string(),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    // Hospital fields
    hospitalName: v.optional(v.string()),
    hospitalLicense: v.optional(v.string()),
    // Doctor fields
    specialization: v.optional(v.string()),
    licenseNumber: v.optional(v.string()),
    hospitalId: v.optional(v.id("userProfiles")),
    // Medical store fields
    storeName: v.optional(v.string()),
    storeAddress: v.optional(v.string()),
    pharmacyLicense: v.optional(v.string()),
    // Patient fields
    dateOfBirth: v.optional(v.string()),
    bloodGroup: v.optional(v.string()),
    emergencyContact: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if profile already exists
    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (existingProfile) {
      throw new Error("Profile already exists");
    }

    // Admin accounts are auto-approved, others need approval
    const isApproved = args.role === "admin" || args.role === "patient";

    return await ctx.db.insert("userProfiles", {
      userId,
      role: args.role,
      name: args.name,
      phone: args.phone,
      address: args.address,
      hospitalName: args.hospitalName,
      hospitalLicense: args.hospitalLicense,
      specialization: args.specialization,
      licenseNumber: args.licenseNumber,
      hospitalId: args.hospitalId,
      storeName: args.storeName,
      storeAddress: args.storeAddress,
      pharmacyLicense: args.pharmacyLicense,
      dateOfBirth: args.dateOfBirth,
      bloodGroup: args.bloodGroup,
      emergencyContact: args.emergencyContact,
      isApproved,
    });
  },
});

export const getPendingApprovals = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const currentUser = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!currentUser || currentUser.role !== "admin") {
      return [];
    }

    return await ctx.db
      .query("userProfiles")
      .withIndex("by_approval_status", (q) => q.eq("isApproved", false))
      .collect();
  },
});

export const approveUser = mutation({
  args: { profileId: v.id("userProfiles") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const currentUser = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!currentUser || currentUser.role !== "admin") {
      throw new Error("Only admins can approve users");
    }

    await ctx.db.patch(args.profileId, { isApproved: true });
  },
});

export const getHospitals = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("userProfiles")
      .withIndex("by_role", (q) => q.eq("role", "hospital"))
      .filter((q) => q.eq(q.field("isApproved"), true))
      .collect();
  },
});

export const getDoctorsByHospital = query({
  args: { hospitalId: v.id("userProfiles") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("userProfiles")
      .withIndex("by_hospital", (q) => q.eq("hospitalId", args.hospitalId))
      .filter((q) => q.eq(q.field("role"), "doctor"))
      .filter((q) => q.eq(q.field("isApproved"), true))
      .collect();
  },
});
