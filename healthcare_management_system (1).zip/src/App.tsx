import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { ProfileSetup } from "./components/ProfileSetup";
import { AdminDashboard } from "./components/AdminDashboard";
import { HospitalDashboard } from "./components/HospitalDashboard";
import { DoctorDashboard } from "./components/DoctorDashboard";
import { MedicalStoreDashboard } from "./components/MedicalStoreDashboard";
import { PatientDashboard } from "./components/PatientDashboard";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4">
        <h2 className="text-xl font-semibold text-blue-600">HealthCare Management</h2>
        <Authenticated>
          <SignOutButton />
        </Authenticated>
      </header>
      <main className="flex-1 p-4">
        <Content />
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const userProfile = useQuery(api.users.getCurrentUserProfile);

  if (userProfile === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <Unauthenticated>
        <div className="max-w-md mx-auto mt-20">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Healthcare Management System</h1>
            <p className="text-lg text-gray-600">Sign in to access your dashboard</p>
          </div>
          <SignInForm />
        </div>
      </Unauthenticated>

      <Authenticated>
        {!userProfile?.profile ? (
          <ProfileSetup />
        ) : !userProfile.profile.isApproved ? (
          <div className="max-w-md mx-auto mt-20 text-center">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-yellow-800 mb-2">Account Pending Approval</h2>
              <p className="text-yellow-700">
                Your account is waiting for admin approval. You'll be notified once it's approved.
              </p>
            </div>
          </div>
        ) : (
          <RoleDashboard role={userProfile.profile.role} />
        )}
      </Authenticated>
    </div>
  );
}

function RoleDashboard({ role }: { role: string }) {
  switch (role) {
    case "admin":
      return <AdminDashboard />;
    case "hospital":
      return <HospitalDashboard />;
    case "doctor":
      return <DoctorDashboard />;
    case "medical_store":
      return <MedicalStoreDashboard />;
    case "patient":
      return <PatientDashboard />;
    default:
      return <div>Unknown role</div>;
  }
}
