import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function PatientDashboard() {
  const [activeTab, setActiveTab] = useState("appointments");
  const [selectedMedicines, setSelectedMedicines] = useState<any[]>([]);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [orderData, setOrderData] = useState({
    deliveryAddress: "",
  });
  const [showBooking, setShowBooking] = useState(false);
  const [bookingData, setBookingData] = useState({
    hospitalId: "",
    doctorId: "",
    appointmentDate: "",
    appointmentTime: "",
    symptoms: "",
  });

  const hospitals = useQuery(api.users.getHospitals);
  const doctors = useQuery(
    api.users.getDoctorsByHospital,
    bookingData.hospitalId ? { hospitalId: bookingData.hospitalId as any } : "skip"
  );
  const appointments = useQuery(api.appointments.getMyAppointments);
  const medicines = useQuery(api.medicines.getMedicines, {});
  const medicineOrders = useQuery(api.medicines.getMedicineOrders);

  const createAppointment = useMutation(api.appointments.createAppointment);
  const createMedicineOrder = useMutation(api.medicines.createMedicineOrder);

  const handleBookAppointment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!bookingData.hospitalId || !bookingData.doctorId || !bookingData.appointmentDate || !bookingData.appointmentTime) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await createAppointment({
        hospitalId: bookingData.hospitalId as any,
        doctorId: bookingData.doctorId as any,
        appointmentDate: bookingData.appointmentDate,
        appointmentTime: bookingData.appointmentTime,
        symptoms: bookingData.symptoms || undefined,
      });
      toast.success("Appointment booked successfully!");
      setShowBooking(false);
      setBookingData({
        hospitalId: "",
        doctorId: "",
        appointmentDate: "",
        appointmentTime: "",
        symptoms: "",
      });
    } catch (error) {
      toast.error("Failed to book appointment");
    }
  };

  const addToCart = (medicine: any) => {
    const existing = selectedMedicines.find(m => m._id === medicine._id);
    if (existing) {
      setSelectedMedicines(selectedMedicines.map(m => 
        m._id === medicine._id ? { ...m, quantity: m.quantity + 1 } : m
      ));
    } else {
      setSelectedMedicines([...selectedMedicines, { ...medicine, quantity: 1 }]);
    }
    toast.success("Added to cart");
  };

  const tabs = [
    { id: "appointments", label: "My Appointments" },
    { id: "medicines", label: "Browse Medicines" },
    { id: "orders", label: "Medicine Orders" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Patient Dashboard</h1>
        <p className="text-gray-600">Manage your appointments and medicine orders</p>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "appointments" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-900">My Appointments</h2>
                <button
                  onClick={() => setShowBooking(true)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                >
                  Book New Appointment
                </button>
              </div>

              {showBooking && (
                <div className="bg-gray-50 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Book New Appointment</h3>
                  <form onSubmit={handleBookAppointment} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Hospital *
                        </label>
                        <select
                          value={bookingData.hospitalId}
                          onChange={(e) => setBookingData({ ...bookingData, hospitalId: e.target.value, doctorId: "" })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        >
                          <option value="">Select a hospital...</option>
                          {hospitals?.map((hospital) => (
                            <option key={hospital._id} value={hospital._id}>
                              {hospital.hospitalName}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Doctor *
                        </label>
                        <select
                          value={bookingData.doctorId}
                          onChange={(e) => setBookingData({ ...bookingData, doctorId: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                          disabled={!bookingData.hospitalId}
                        >
                          <option value="">Select a doctor...</option>
                          {doctors?.map((doctor) => (
                            <option key={doctor._id} value={doctor._id}>
                              {doctor.name} - {doctor.specialization}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Date *
                        </label>
                        <input
                          type="date"
                          value={bookingData.appointmentDate}
                          onChange={(e) => setBookingData({ ...bookingData, appointmentDate: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                          min={new Date().toISOString().split('T')[0]}
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Time *
                        </label>
                        <input
                          type="time"
                          value={bookingData.appointmentTime}
                          onChange={(e) => setBookingData({ ...bookingData, appointmentTime: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Symptoms (Optional)
                      </label>
                      <textarea
                        value={bookingData.symptoms}
                        onChange={(e) => setBookingData({ ...bookingData, symptoms: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        rows={3}
                        placeholder="Describe your symptoms..."
                      />
                    </div>

                    <div className="flex space-x-4">
                      <button
                        type="submit"
                        className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                      >
                        Book Appointment
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowBooking(false)}
                        className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {appointments === undefined ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : appointments.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No appointments found</p>
              ) : (
                <div className="space-y-4">
                  {appointments.map((appointment) => (
                    <div key={appointment._id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            Dr. {appointment.doctor?.name}
                          </h3>
                          <p className="text-sm text-gray-600">{appointment.doctor?.specialization}</p>
                          <p className="text-sm text-gray-600">{appointment.hospital?.hospitalName}</p>
                          <p className="text-sm text-gray-600">
                            {appointment.appointmentDate} at {appointment.appointmentTime}
                          </p>
                          {appointment.symptoms && (
                            <p className="text-sm text-gray-600 mt-2">
                              <strong>Symptoms:</strong> {appointment.symptoms}
                            </p>
                          )}
                          {appointment.diagnosis && (
                            <p className="text-sm text-gray-600 mt-2">
                              <strong>Diagnosis:</strong> {appointment.diagnosis}
                            </p>
                          )}
                          {appointment.prescription && (
                            <p className="text-sm text-gray-600 mt-2">
                              <strong>Prescription:</strong> {appointment.prescription}
                            </p>
                          )}
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          appointment.status === "scheduled" ? "bg-blue-100 text-blue-800" :
                          appointment.status === "completed" ? "bg-green-100 text-green-800" :
                          "bg-red-100 text-red-800"
                        }`}>
                          {appointment.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "medicines" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-900">Browse Medicines</h2>
                {selectedMedicines.length > 0 && (
                  <button
                    onClick={() => setShowOrderForm(true)}
                    className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
                  >
                    Cart ({selectedMedicines.length})
                  </button>
                )}
              </div>
              
              {medicines === undefined ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : medicines.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No medicines available</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {medicines.map((medicine) => (
                    <div key={medicine._id} className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-900">{medicine.name}</h3>
                      <p className="text-sm text-gray-600">{medicine.manufacturer}</p>
                      <p className="text-sm text-gray-600">Category: {medicine.category}</p>
                      <p className="text-sm text-gray-600">Price: ₹{medicine.price}</p>
                      <p className="text-sm text-gray-600">Stock: {medicine.stockQuantity}</p>
                      {medicine.requiresPrescription && (
                        <span className="inline-block bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full mt-2">
                          Prescription Required
                        </span>
                      )}
                      <button
                        onClick={() => addToCart(medicine)}
                        className="w-full mt-3 bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                      >
                        Add to Cart
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "orders" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Medicine Orders</h2>
              
              {medicineOrders === undefined ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : medicineOrders.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No orders found</p>
              ) : (
                <div className="space-y-4">
                  {medicineOrders.map((order) => (
                    <div key={order._id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm text-gray-600">Order ID: {order._id}</p>
                          <p className="text-sm text-gray-600">Total: ₹{order.totalAmount}</p>
                          <p className="text-sm text-gray-600">Items: {order.medicines.length}</p>
                          <p className="text-sm text-gray-600">Delivery: {order.deliveryAddress}</p>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          order.status === "pending" ? "bg-yellow-100 text-yellow-800" :
                          order.status === "confirmed" ? "bg-blue-100 text-blue-800" :
                          order.status === "delivered" ? "bg-green-100 text-green-800" :
                          "bg-red-100 text-red-800"
                        }`}>
                          {order.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
