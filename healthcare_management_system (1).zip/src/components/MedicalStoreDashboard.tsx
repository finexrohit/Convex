import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function MedicalStoreDashboard() {
  const [activeTab, setActiveTab] = useState("medicines");
  const [showAddMedicine, setShowAddMedicine] = useState(false);
  const [medicineData, setMedicineData] = useState({
    name: "",
    description: "",
    manufacturer: "",
    category: "",
    price: "",
    stockQuantity: "",
    expiryDate: "",
    requiresPrescription: false,
  });

  const medicines = useQuery(api.medicines.getMedicines, {});
  const medicineOrders = useQuery(api.medicines.getMedicineOrders);
  const addMedicine = useMutation(api.medicines.addMedicine);

  const handleAddMedicine = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!medicineData.name || !medicineData.manufacturer || !medicineData.category || !medicineData.price || !medicineData.stockQuantity || !medicineData.expiryDate) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await addMedicine({
        name: medicineData.name,
        description: medicineData.description || undefined,
        manufacturer: medicineData.manufacturer,
        category: medicineData.category,
        price: parseFloat(medicineData.price),
        stockQuantity: parseInt(medicineData.stockQuantity),
        expiryDate: medicineData.expiryDate,
        requiresPrescription: medicineData.requiresPrescription,
      });
      toast.success("Medicine added successfully!");
      setShowAddMedicine(false);
      setMedicineData({
        name: "",
        description: "",
        manufacturer: "",
        category: "",
        price: "",
        stockQuantity: "",
        expiryDate: "",
        requiresPrescription: false,
      });
    } catch (error) {
      toast.error("Failed to add medicine");
    }
  };

  const tabs = [
    { id: "medicines", label: "Medicine Inventory" },
    { id: "orders", label: "Orders" },
    { id: "analytics", label: "Analytics" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Medical Store Dashboard</h1>
        <p className="text-gray-600">Manage your medicine inventory and orders</p>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "medicines" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-900">Medicine Inventory</h2>
                <button
                  onClick={() => setShowAddMedicine(true)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                >
                  Add New Medicine
                </button>
              </div>

              {showAddMedicine && (
                <div className="bg-gray-50 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Medicine</h3>
                  <form onSubmit={handleAddMedicine} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Medicine Name *
                        </label>
                        <input
                          type="text"
                          value={medicineData.name}
                          onChange={(e) => setMedicineData({ ...medicineData, name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Manufacturer *
                        </label>
                        <input
                          type="text"
                          value={medicineData.manufacturer}
                          onChange={(e) => setMedicineData({ ...medicineData, manufacturer: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Category *
                        </label>
                        <select
                          value={medicineData.category}
                          onChange={(e) => setMedicineData({ ...medicineData, category: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        >
                          <option value="">Select category...</option>
                          <option value="Antibiotics">Antibiotics</option>
                          <option value="Pain Relief">Pain Relief</option>
                          <option value="Vitamins">Vitamins</option>
                          <option value="Heart">Heart</option>
                          <option value="Diabetes">Diabetes</option>
                          <option value="Blood Pressure">Blood Pressure</option>
                          <option value="Skin Care">Skin Care</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Price (₹) *
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          value={medicineData.price}
                          onChange={(e) => setMedicineData({ ...medicineData, price: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Stock Quantity *
                        </label>
                        <input
                          type="number"
                          value={medicineData.stockQuantity}
                          onChange={(e) => setMedicineData({ ...medicineData, stockQuantity: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Expiry Date *
                        </label>
                        <input
                          type="date"
                          value={medicineData.expiryDate}
                          onChange={(e) => setMedicineData({ ...medicineData, expiryDate: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Description
                      </label>
                      <textarea
                        value={medicineData.description}
                        onChange={(e) => setMedicineData({ ...medicineData, description: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        rows={3}
                        placeholder="Enter medicine description..."
                      />
                    </div>

                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="requiresPrescription"
                        checked={medicineData.requiresPrescription}
                        onChange={(e) => setMedicineData({ ...medicineData, requiresPrescription: e.target.checked })}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor="requiresPrescription" className="ml-2 block text-sm text-gray-900">
                        Requires Prescription
                      </label>
                    </div>

                    <div className="flex space-x-4">
                      <button
                        type="submit"
                        className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                      >
                        Add Medicine
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAddMedicine(false)}
                        className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {medicines === undefined ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : medicines.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No medicines in inventory</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {medicines.map((medicine) => (
                    <div key={medicine._id} className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-900">{medicine.name}</h3>
                      <p className="text-sm text-gray-600">{medicine.manufacturer}</p>
                      <p className="text-sm text-gray-600">Category: {medicine.category}</p>
                      <p className="text-sm text-gray-600">Price: ₹{medicine.price}</p>
                      <p className="text-sm text-gray-600">Stock: {medicine.stockQuantity}</p>
                      <p className="text-sm text-gray-600">Expires: {medicine.expiryDate}</p>
                      {medicine.requiresPrescription && (
                        <span className="inline-block bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full mt-2">
                          Prescription Required
                        </span>
                      )}
                      {medicine.stockQuantity < 10 && (
                        <span className="inline-block bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full mt-2 ml-2">
                          Low Stock
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "orders" && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-gray-900">Medicine Orders</h2>
              
              {medicineOrders === undefined ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : medicineOrders.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No orders found</p>
              ) : (
                <div className="space-y-4">
                  {medicineOrders.map((order) => (
                    <div key={order._id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-semibold text-gray-900">Order #{order._id.slice(-8)}</p>
                          <p className="text-sm text-gray-600">Total: ₹{order.totalAmount}</p>
                          <p className="text-sm text-gray-600">Items: {order.medicines.length}</p>
                          <p className="text-sm text-gray-600">Delivery: {order.deliveryAddress}</p>
                          {order.prescriptionRequired && (
                            <p className="text-sm text-yellow-600 mt-1">⚠️ Prescription Required</p>
                          )}
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          order.status === "pending" ? "bg-yellow-100 text-yellow-800" :
                          order.status === "confirmed" ? "bg-blue-100 text-blue-800" :
                          order.status === "delivered" ? "bg-green-100 text-green-800" :
                          "bg-red-100 text-red-800"
                        }`}>
                          {order.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "analytics" && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-900">Store Analytics</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-blue-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-blue-900">Total Medicines</h3>
                  <p className="text-3xl font-bold text-blue-600 mt-2">
                    {medicines?.length || 0}
                  </p>
                </div>
                
                <div className="bg-green-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-green-900">Total Orders</h3>
                  <p className="text-3xl font-bold text-green-600 mt-2">
                    {medicineOrders?.length || 0}
                  </p>
                </div>
                
                <div className="bg-yellow-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-yellow-900">Low Stock Items</h3>
                  <p className="text-3xl font-bold text-yellow-600 mt-2">
                    {medicines?.filter(m => m.stockQuantity < 10).length || 0}
                  </p>
                </div>
                
                <div className="bg-purple-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-purple-900">Revenue</h3>
                  <p className="text-3xl font-bold text-purple-600 mt-2">
                    ₹{medicineOrders?.reduce((sum, order) => sum + order.totalAmount, 0) || 0}
                  </p>
                </div>
              </div>

              <div className="bg-white border rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-4">Low Stock Alert</h3>
                {medicines?.filter(m => m.stockQuantity < 10).length === 0 ? (
                  <p className="text-gray-500">All medicines are well stocked</p>
                ) : (
                  <div className="space-y-2">
                    {medicines?.filter(m => m.stockQuantity < 10).map((medicine) => (
                      <div key={medicine._id} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                        <div>
                          <p className="font-medium">{medicine.name}</p>
                          <p className="text-sm text-gray-600">{medicine.manufacturer}</p>
                        </div>
                        <span className="text-sm text-red-600 font-medium">
                          {medicine.stockQuantity} left
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
