import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function AdminDashboard() {
  const pendingApprovals = useQuery(api.users.getPendingApprovals);
  const approveUser = useMutation(api.users.approveUser);

  const handleApprove = async (profileId: string) => {
    try {
      await approveUser({ profileId: profileId as any });
      toast.success("User approved successfully!");
    } catch (error) {
      toast.error("Failed to approve user");
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
        <p className="text-gray-600">Manage user approvals and system overview</p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Pending User Approvals</h2>
        
        {pendingApprovals === undefined ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : pendingApprovals.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No pending approvals</p>
        ) : (
          <div className="space-y-4">
            {pendingApprovals.map((profile) => (
              <div key={profile._id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{profile.name}</h3>
                    <p className="text-sm text-gray-600 capitalize">Role: {profile.role.replace('_', ' ')}</p>
                    
                    {profile.role === "hospital" && (
                      <div className="mt-2 text-sm text-gray-600">
                        <p>Hospital: {profile.hospitalName}</p>
                        <p>License: {profile.hospitalLicense}</p>
                      </div>
                    )}
                    
                    {profile.role === "doctor" && (
                      <div className="mt-2 text-sm text-gray-600">
                        <p>Specialization: {profile.specialization}</p>
                        <p>License: {profile.licenseNumber}</p>
                      </div>
                    )}
                    
                    {profile.role === "medical_store" && (
                      <div className="mt-2 text-sm text-gray-600">
                        <p>Store: {profile.storeName}</p>
                        <p>License: {profile.pharmacyLicense}</p>
                      </div>
                    )}
                    
                    <p className="text-sm text-gray-600 mt-1">Phone: {profile.phone}</p>
                    <p className="text-sm text-gray-600">Address: {profile.address}</p>
                  </div>
                  
                  <button
                    onClick={() => handleApprove(profile._id)}
                    className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500"
                  >
                    Approve
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
